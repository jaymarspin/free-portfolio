@extends("admin.admin-head")

@section("content")
@include("admin.admin-nav")
<link rel="stylesheet" type="text/css" href="{{asset('css/admin/works.css')}}">
<div class="row mycontainer time">
</div>
@endsection