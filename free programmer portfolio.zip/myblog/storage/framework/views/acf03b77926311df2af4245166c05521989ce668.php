<?php $__env->startSection("content"); ?>
<?php echo $__env->make("admin.admin-nav", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/works.css')); ?>">
<div class="row mycontainer time">
</div>
<style>
    table{
        margin: auto;
        margin-top: 100px;
      
       
        width: 100%;
    }
</style>
<div class="container">
    <h1>Messages</h1>
    <table class="table table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Person</th>
            <th>Topic</th>
            <th>Message</th>
           
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(($key + 1)); ?></td>
                <td><?php echo e($item['person']); ?></td>
                <td><?php echo e($item['topic']); ?></td>
                <td><?php echo e($item['message']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr></tr>
        </tbody>
        
    </table>
    <?php echo e($messages->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.admin-head", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>